import React, { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'

const navItems = [
  { path: '/dashboard', label: 'Dashboard', icon: '▦' },
  { path: '/supplier', label: 'Suppliers', icon: '◇' },
  { path: '/shipment', label: 'Shipments', icon: '▣' },
  { path: '/delivery', label: 'Deliveries', icon: '↗' },
  { path: '/reports', label: 'Reports', icon: '▤' },
]

function BrandCube() {
  return (
    <svg className="brand-cube" viewBox="0 0 48 48" aria-hidden="true">
      <path d="M24 3 44 14.5v19L24 45 4 33.5v-19L24 3Z" fill="#13c5c6" />
      <path d="m24 3 20 11.5L24 26 4 14.5 24 3Z" fill="#48e3d6" />
      <path d="M4 14.5 24 26v19L4 33.5v-19Z" fill="#11a8b8" />
      <path d="M24 26 44 14.5v19L24 45V26Z" fill="#087f9b" />
      <path d="m21 21.5 3 1.7v8.2l-3-1.7v-8.2Zm5 2.8 3-1.7v5.5l-3 1.7v-5.5Z" fill="#d5fffa" />
    </svg>
  )
}

function Navbar({ onLogout }) {
  const location = useLocation()
  const [isOpen, setIsOpen] = useState(false)
  const username = localStorage.getItem('username') || 'Administrator'
  const initials = username.slice(0, 2).toUpperCase()

  useEffect(() => {
    setIsOpen(false)
  }, [location.pathname])

  return (
    <>
      <div className="mobile-toolbar">
        <Link to="/dashboard" className="mobile-brand">
          <BrandCube />
          SCMS
        </Link>
        <button
          type="button"
          className="mobile-menu-button"
          onClick={() => setIsOpen(!isOpen)}
          aria-label={isOpen ? 'Close navigation menu' : 'Open navigation menu'}
          aria-expanded={isOpen}
        >
          {isOpen ? '×' : '☰'}
        </button>
      </div>

      {isOpen && (
        <button
          type="button"
          className="sidebar-overlay"
          onClick={() => setIsOpen(false)}
          aria-label="Close navigation menu"
        />
      )}

      <aside className={`sidebar${isOpen ? ' is-open' : ''}`}>
        <Link to="/dashboard" className="brand">
          <BrandCube />
          <span>
            <p className="brand-name">SCMS</p>
            <p className="brand-caption">SUPPLY OPERATIONS</p>
          </span>
        </Link>

        <p className="nav-caption">Workspace</p>
        <nav className="nav-links" aria-label="Main navigation">
          {navItems.map((item) => {
            const active = location.pathname === item.path
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`nav-link${active ? ' active' : ''}`}
                aria-current={active ? 'page' : undefined}
              >
                <span className="nav-icon" aria-hidden="true">{item.icon}</span>
                {item.label}
              </Link>
            )
          })}
        </nav>

        <div className="sidebar-footer">
          <div className="user-card">
            <span className="user-avatar">{initials}</span>
            <span>
              <p className="user-name">{username}</p>
              <p className="user-role">System administrator</p>
            </span>
          </div>
          <button type="button" className="logout-button" onClick={onLogout}>
            Sign Out
          </button>
        </div>
      </aside>
    </>
  )
}

export default Navbar
