import React, { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import { API_BASE_URL } from '../api'

function BrandMark() {
  return (
    <svg className="login-brand-mark" viewBox="0 0 48 48" aria-hidden="true">
      <path d="M24 3 44 14.5v19L24 45 4 33.5v-19L24 3Z" fill="#13c5c6" />
      <path d="m24 3 20 11.5L24 26 4 14.5 24 3Z" fill="#48e3d6" />
      <path d="M4 14.5 24 26v19L4 33.5v-19Z" fill="#11a8b8" />
      <path d="M24 26 44 14.5v19L24 45V26Z" fill="#087f9b" />
      <path d="m24 10 8 4.6-8 4.6-8-4.6 8-4.6Z" fill="#073b58" />
      <path d="m21 21.5 3 1.7v8.2l-3-1.7v-8.2Zm5 2.8 3-1.7v5.5l-3 1.7v-5.5Z" fill="#d5fffa" />
    </svg>
  )
}

function FieldIcon({ type }) {
  return type === 'user' ? (
    <svg viewBox="0 0 20 20" aria-hidden="true">
      <circle cx="10" cy="6.3" r="3" />
      <path d="M4.5 16v-1.2a5.5 5.5 0 0 1 11 0V16h-11Z" />
    </svg>
  ) : (
    <svg viewBox="0 0 20 20" aria-hidden="true">
      <rect x="4.5" y="8.5" width="11" height="8" rx="1.5" />
      <path d="M7 8.5V6a3 3 0 0 1 6 0v2.5" />
    </svg>
  )
}

function Login({ onLogin }) {
  const [username, setUsername] = useState(() => localStorage.getItem('rememberedUsername') || '')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [loading, setLoading] = useState(false)
  const [rememberMe, setRememberMe] = useState(() => Boolean(localStorage.getItem('rememberedUsername')))
  const navigate = useNavigate()

  const handleSubmit = async (event) => {
    event.preventDefault()
    setError('')
    setNotice('')
    setLoading(true)

    try {
      const response = await axios.post(`${API_BASE_URL}/login`, { username, password })
      if (!response.data.success) {
        setError(response.data.message || 'Unable to sign in.')
        return
      }

      localStorage.setItem('isAuthenticated', 'true')
      localStorage.setItem('username', response.data.user?.username || username)
      if (rememberMe) {
        localStorage.setItem('rememberedUsername', username)
      } else {
        localStorage.removeItem('rememberedUsername')
      }
      onLogin()
      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.message || 'Could not connect to the server. Check that the backend is running.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="login-page">
      <section className="login-intro">
        <div className="login-brand">
          <BrandMark />
          <span className="login-brand-copy">
            <span className="login-brand-name">SCMS</span>
            <span className="login-brand-caption">SUPPLY OPERATIONS</span>
          </span>
        </div>
        <div className="login-intro-copy">
          <h1>Smarter Supply<br />Chain. Stronger<br /><span>Business.</span></h1>
          <p>Track, manage, and deliver with confidence.</p>
          <span className="login-accent-line" />
        </div>
        <p className="login-photo-credit">SCMS · SUPPLY OPERATIONS</p>
      </section>

      <section className="login-panel">
        <div className="login-card">
          <p className="login-welcome">Welcome Back!</p>
          <h2>Sign in to SCMS</h2>
          <p className="login-subtitle">Enter your credentials to continue.</p>

          <form className="login-form" onSubmit={handleSubmit}>
            {error && <div className="alert alert-error" role="alert">{error}</div>}
            <label className="login-input-wrap" htmlFor="username">
              <FieldIcon type="user" />
              <input
                className="login-input"
                id="username"
                type="text"
                autoComplete="username"
                value={username}
                onChange={(event) => setUsername(event.target.value)}
                placeholder="Username"
                required
              />
            </label>
            <label className="login-input-wrap" htmlFor="password">
              <FieldIcon type="password" />
              <input
                className="login-input"
                id="password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="Password"
                required
              />
            </label>
            <div className="login-options">
              <label className="remember-option">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(event) => setRememberMe(event.target.checked)}
                />
                <span>Remember me</span>
              </label>
              <button
                type="button"
                className="login-text-link"
                onClick={() => setNotice('Please contact your SCMS administrator to reset your password.')}
              >
                Forgot password?
              </button>
            </div>
            {notice && <p className="login-notice" role="status">{notice}</p>}
            <button type="submit" className="login-submit" disabled={loading}>
              <span aria-hidden="true">➜</span>
              {loading ? 'Signing in…' : 'Sign In'}
            </button>
          </form>

          <p className="login-register">
            Don’t have an account?{' '}
            <button
              type="button"
              className="login-text-link"
              onClick={() => setNotice('New accounts are managed by your SCMS administrator.')}
            >
              Register here
            </button>
          </p>
        </div>
      </section>
    </div>
  )
}

export default Login
