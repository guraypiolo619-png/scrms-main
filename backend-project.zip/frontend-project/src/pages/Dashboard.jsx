import React, { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import { API_BASE_URL } from '../api'
import { getShipmentDateAlerts } from '../utils/shipmentAlerts'

const statusClass = (status) => `status-pill status-${(status || 'pending').toLowerCase().replace(/\s+/g, '-')}`

function DashboardIcon({ name }) {
  const paths = {
    suppliers: <><circle cx="8" cy="8" r="3" /><path d="M2.5 19v-1.2a5.5 5.5 0 0 1 11 0V19h-11Zm12-9a3 3 0 1 0 0-6m1 10a5.5 5.5 0 0 1 3.5 5" /></>,
    transit: <><path d="M3 5h10v12H3zM13 9h4l3 3v5h-7z" /><circle cx="7" cy="18" r="1.7" /><circle cx="17" cy="18" r="1.7" /></>,
    delivered: <><circle cx="12" cy="12" r="9" /><path d="m8 12 2.5 2.5L16.5 9" /></>,
    shipments: <><path d="m12 2 9 5-9 5-9-5 9-5Zm-9 5v10l9 5 9-5V7M12 12v10" /></>,
  }

  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      {paths[name]}
    </svg>
  )
}

function Dashboard() {
  const [overview, setOverview] = useState({ suppliers: [], shipments: [], deliveries: [] })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')

  const fetchOverview = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const [suppliers, shipments, deliveries] = await Promise.all([
        axios.get(`${API_BASE_URL}/suppliers`),
        axios.get(`${API_BASE_URL}/shipments`),
        axios.get(`${API_BASE_URL}/deliveries`)
      ])
      setOverview({
        suppliers: suppliers.data.data || [],
        shipments: shipments.data.data || [],
        deliveries: deliveries.data.data || []
      })
    } catch (err) {
      setError('Could not load live operations data. Check that the backend and database are running.')
      console.error('Error fetching dashboard data:', err)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchOverview()
  }, [fetchOverview])

  const inTransit = overview.shipments.filter(({ shipmentStatus }) => shipmentStatus === 'In Transit').length
  const delivered = overview.shipments.filter(({ shipmentStatus }) => shipmentStatus === 'Delivered').length
  const now = new Date()
  const todayKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`
  const { overdueDepartures, lateInTransit, shipmentsNeedingAttention, attentionSummary } = getShipmentDateAlerts(
    overview.shipments,
    todayKey
  )
  const latestShipments = [...overview.shipments].slice(0, 5)
  const visibleShipments = latestShipments.filter((shipment) => (
    [shipment.shipmentNumber, shipment.supplierName, shipment.destination, shipment.shipmentStatus]
      .some((value) => String(value || '').toLowerCase().includes(search.toLowerCase()))
  ))
  const username = localStorage.getItem('username') || 'Administrator'
  const initials = username.slice(0, 2).toUpperCase()
  const today = now.toLocaleDateString(undefined, {
    weekday: 'long', month: 'long', day: 'numeric', year: 'numeric'
  })

  const metrics = [
    { name: 'suppliers', label: 'Total Suppliers', value: overview.suppliers.length, note: 'Active supply partners' },
    { name: 'transit', label: 'In Transit', value: inTransit, note: 'Shipments on the move' },
    { name: 'delivered', label: 'Delivered', value: delivered, note: 'Successfully completed' },
    { name: 'shipments', label: 'Total Shipments', value: overview.shipments.length, note: 'Across your network' },
  ]

  return (
    <div className="dashboard-page">
      <header className="dashboard-topbar">
        <label className="dashboard-search">
          <svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="8.7" cy="8.7" r="5.7" /><path d="m13 13 4 4" /></svg>
          <input
            type="search"
            aria-label="Search recent shipments"
            placeholder="Search anything..."
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </label>
        <div className="dashboard-topbar-meta">
          <span className="dashboard-date">{today}</span>
          <span className="dashboard-notification" aria-label="Notifications">
            <svg viewBox="0 0 20 20" aria-hidden="true"><path d="M15.5 7.5a5.5 5.5 0 0 0-11 0c0 6-2 6.5-2 7.5h15c0-1-2-1.5-2-7.5ZM8 18h4" /></svg>
            <i />
          </span>
          <span className="dashboard-avatar" title={username}>{initials}</span>
        </div>
      </header>

      <main className="dashboard-content">
        {error && (
          <div className="alert alert-error alert-with-action" role="alert">
            <span>{error}</span>
            <button type="button" className="btn btn-secondary alert-retry" onClick={fetchOverview}>
              Retry
            </button>
          </div>
        )}

        <section className="dashboard-welcome">
          <div className="dashboard-welcome-copy">
            <p className="eyebrow">Dashboard</p>
            <h1>Good to see you, {username}!</h1>
            <p>Here’s what’s happening with your supply chain today.</p>
          </div>
          <div className="dashboard-hero-art" role="img" aria-label="Cargo ship at a port" />
        </section>

        <section className="dashboard-metrics" aria-label="Supply chain metrics">
          {metrics.map((metric) => (
            <article className="dashboard-metric-card" key={metric.name}>
              <span className={`dashboard-metric-icon dashboard-metric-icon-${metric.name}`}>
                <DashboardIcon name={metric.name} />
              </span>
              <span className="dashboard-metric-copy">
                <span className="dashboard-metric-label">{metric.label}</span>
                <strong className="dashboard-metric-value">{loading || error ? '—' : metric.value}</strong>
                <span className="dashboard-metric-note">{metric.note}</span>
              </span>
            </article>
          ))}
        </section>

        <section
          className={`dashboard-alert-card ${loading ? 'is-loading' : error ? 'is-error' : shipmentsNeedingAttention.length ? 'is-overdue' : 'is-clear'}`}
          aria-labelledby="dashboard-alert-title"
        >
          <span className="dashboard-alert-icon" aria-hidden="true">
            {loading ? '…' : error || shipmentsNeedingAttention.length ? '!' : '✓'}
          </span>
          <div className="dashboard-alert-copy" aria-live="polite">
            <h2 id="dashboard-alert-title">Shipment schedule</h2>
            {loading ? (
              <p>Checking pending shipments…</p>
            ) : error ? (
              <p>Shipment date alerts are unavailable until operations data loads.</p>
            ) : shipmentsNeedingAttention.length ? (
              <>
                <p><strong>{attentionSummary}.</strong></p>
                <ul className="dashboard-alert-list">
                  {shipmentsNeedingAttention.slice(0, 3).map((shipment) => (
                    <li key={shipment.shipmentNumber}>
                      <div className="dashboard-alert-detail">
                        <span className={`dashboard-alert-kind${shipment.attentionType === 'Late in transit' ? ' is-late' : ''}`}>
                          {shipment.attentionType}
                        </span>
                        <span>
                          <strong>#{shipment.shipmentNumber}</strong>
                          {' · '}{shipment.supplierName || 'Supplier not specified'}
                          {' · '}{shipment.destination || 'Destination not specified'}
                        </span>
                      </div>
                      <time dateTime={shipment.attentionDate}>
                        {shipment.attentionType === 'Late in transit' ? 'Expected ' : 'Ship date '}
                        {shipment.attentionDate}
                      </time>
                    </li>
                  ))}
                </ul>
                {shipmentsNeedingAttention.length > 3 && (
                  <p className="dashboard-alert-more">
                    And {shipmentsNeedingAttention.length - 3} more shipments need attention.
                  </p>
                )}
              </>
            ) : (
              <p>No pending shipments are past their scheduled dates, and no in-transit shipments with an expected date are late.</p>
            )}
          </div>
          <Link to="/shipment" className="dashboard-alert-action">
            Review shipments <span aria-hidden="true">→</span>
          </Link>
        </section>

        <section className="dashboard-lower-grid">
          <article className="dashboard-table-card">
            <div className="dashboard-section-heading">
              <div>
                <h2>Recent Shipments</h2>
                <p>Your latest shipment activity</p>
              </div>
              <Link to="/shipment" className="dashboard-view-all">View All <span aria-hidden="true">→</span></Link>
            </div>
            <div className="dashboard-table-scroll">
              <table className="dashboard-table">
                <thead>
                  <tr>
                    <th>Shipment #</th>
                    <th>Supplier</th>
                    <th>Destination</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {!loading && error && (
                    <tr><td className="empty-state" colSpan="5">Shipment data is unavailable until loading succeeds.</td></tr>
                  )}
                  {!loading && !error && visibleShipments.length === 0 && (
                    <tr>
                      <td className="empty-state" colSpan="5">
                        {search ? 'No recent shipments match your search.' : 'No shipments have been recorded yet.'}
                      </td>
                    </tr>
                  )}
                  {visibleShipments.map((shipment) => (
                    <tr key={shipment.shipmentNumber}>
                      <td className="dashboard-shipment-number">#{shipment.shipmentNumber}</td>
                      <td>{shipment.supplierName || '—'}</td>
                      <td>{shipment.destination || '—'}</td>
                      <td><span className={statusClass(shipment.shipmentStatus)}>{shipment.shipmentStatus}</span></td>
                      <td><Link to="/shipment" className="dashboard-row-action">View</Link></td>
                    </tr>
                  ))}
                  {loading && <tr><td className="empty-state" colSpan="5">Loading operational data…</td></tr>}
                </tbody>
              </table>
            </div>
          </article>

          <aside className="dashboard-actions-card">
            <div className="dashboard-section-heading">
              <div>
                <h2>Quick Actions</h2>
                <p>Get things moving</p>
              </div>
            </div>
            <div className="dashboard-actions">
              <Link to="/shipment" className="dashboard-action">
                <span className="dashboard-action-icon">＋</span>
                <span>Add Shipment</span>
                <span className="dashboard-action-arrow" aria-hidden="true">→</span>
              </Link>
              <Link to="/reports" className="dashboard-action">
                <span className="dashboard-action-icon">▤</span>
                <span>View Reports</span>
                <span className="dashboard-action-arrow" aria-hidden="true">→</span>
              </Link>
              <Link to="/delivery" className="dashboard-action">
                <span className="dashboard-action-icon">✓</span>
                <span>Manage Deliveries</span>
                <span className="dashboard-action-arrow" aria-hidden="true">→</span>
              </Link>
            </div>
          </aside>
        </section>
      </main>
    </div>
  )
}

export default Dashboard
