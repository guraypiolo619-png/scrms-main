import assert from 'node:assert/strict'
import test from 'node:test'
import { getDeliveryPerformance } from './deliveryPerformance.js'

test('compares completed deliveries with the shipment expected date', () => {
  assert.deepEqual(getDeliveryPerformance({
    deliveryStatus: 'Delivered',
    deliveryDate: '2026-11-20',
    expectedDeliveryDate: '2026-11-20'
  }), { label: 'On time', tone: 'on-time' })

  assert.deepEqual(getDeliveryPerformance({
    deliveryStatus: 'Delivered',
    deliveryDate: '2026-11-22',
    expectedDeliveryDate: '2026-11-20'
  }), { label: 'Late by 2 days', tone: 'late' })
})

test('does not claim timeliness when ETA or completed status is missing', () => {
  assert.deepEqual(getDeliveryPerformance({
    deliveryStatus: 'Delivered',
    deliveryDate: '2026-11-20',
    expectedDeliveryDate: null
  }), { label: 'No ETA', tone: 'unknown' })

  assert.deepEqual(getDeliveryPerformance({
    deliveryStatus: 'In Transit',
    deliveryDate: '2026-11-20',
    expectedDeliveryDate: '2026-11-20'
  }), { label: 'Not delivered', tone: 'pending' })
})
