import React from 'react'

function compareValues(firstValue, secondValue, key) {
  if (firstValue == null) return secondValue == null ? 0 : -1
  if (secondValue == null) return 1

  const firstText = String(firstValue)
  const secondText = String(secondValue)

  if (key.toLowerCase().includes('date')) {
    const firstDate = Date.parse(firstText)
    const secondDate = Date.parse(secondText)
    if (Number.isFinite(firstDate) && Number.isFinite(secondDate)) return firstDate - secondDate
  }

  if (firstText.trim() && secondText.trim()) {
    const firstNumber = Number(firstText)
    const secondNumber = Number(secondText)
    if (Number.isFinite(firstNumber) && Number.isFinite(secondNumber)) return firstNumber - secondNumber
  }

  return firstText.localeCompare(secondText, undefined, { numeric: true, sensitivity: 'base' })
}

export function sortRows(rows, sortKey, sortDirection, tieBreakKey) {
  const direction = sortDirection === 'asc' ? 1 : -1

  return rows
    .map((row, index) => ({ row, index }))
    .sort((first, second) => {
      const primaryOrder = compareValues(first.row[sortKey], second.row[sortKey], sortKey) * direction
      if (primaryOrder) return primaryOrder

      if (tieBreakKey) {
        const tieBreakOrder = compareValues(first.row[tieBreakKey], second.row[tieBreakKey], tieBreakKey) * direction
        if (tieBreakOrder) return tieBreakOrder
      }

      return first.index - second.index
    })
    .map(({ row }) => row)
}

export function SortableHeader({ columnKey, label, sortKey, sortDirection, onSort }) {
  const active = sortKey === columnKey
  const ariaSort = active ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none'
  const indicator = active ? (sortDirection === 'asc' ? '↑' : '↓') : '↕'

  return (
    <th scope="col" aria-sort={ariaSort}>
      <button type="button" className="table-sort-button" onClick={() => onSort(columnKey)}>
        {label}<span className="table-sort-indicator" aria-hidden="true">{indicator}</span>
      </button>
    </th>
  )
}

export function TablePagination({ total, page, pageSize, onPageChange, onPageSizeChange }) {
  const pageCount = Math.max(1, Math.ceil(total / pageSize))
  const firstItem = total === 0 ? 0 : ((page - 1) * pageSize) + 1
  const lastItem = Math.min(page * pageSize, total)

  return (
    <div className="table-pagination" role="group" aria-label="Table pagination">
      <span className="table-pagination-summary">
        Showing {firstItem}-{lastItem} of {total}
      </span>
      <label className="table-page-size">
        <span>Rows per page</span>
        <select value={pageSize} onChange={(event) => onPageSizeChange(Number(event.target.value))}>
          <option value="10">10</option>
          <option value="25">25</option>
          <option value="50">50</option>
        </select>
      </label>
      <div className="table-pagination-controls">
        <button type="button" onClick={() => onPageChange(page - 1)} disabled={page <= 1}>
          Previous
        </button>
        <span aria-live="polite">Page {page} of {pageCount}</span>
        <button type="button" onClick={() => onPageChange(page + 1)} disabled={page >= pageCount}>
          Next
        </button>
      </div>
    </div>
  )
}
