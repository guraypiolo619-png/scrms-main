-- Apply once to an existing SCMS database.
-- Do not run this after creating the schema from the updated database_script.sql.
ALTER TABLE Shipment
ADD COLUMN expectedDeliveryDate DATE NULL AFTER shipmentDate;
