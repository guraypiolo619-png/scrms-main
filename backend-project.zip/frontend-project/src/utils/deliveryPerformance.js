function dateKey(value) {
  const date = String(value || '').slice(0, 10)
  return /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : ''
}

export function getDeliveryPerformance(delivery) {
  if (delivery.deliveryStatus !== 'Delivered') {
    return { label: 'Not delivered', tone: 'pending' }
  }

  const expectedDate = dateKey(delivery.expectedDeliveryDate)
  if (!expectedDate) return { label: 'No ETA', tone: 'unknown' }

  const actualDate = dateKey(delivery.deliveryDate)
  if (!actualDate) return { label: 'No delivery date', tone: 'unknown' }
  if (actualDate <= expectedDate) return { label: 'On time', tone: 'on-time' }

  const daysLate = Math.round(
    (Date.parse(`${actualDate}T00:00:00Z`) - Date.parse(`${expectedDate}T00:00:00Z`)) / 86400000
  )

  return {
    label: `Late by ${daysLate} ${daysLate === 1 ? 'day' : 'days'}`,
    tone: 'late'
  }
}
