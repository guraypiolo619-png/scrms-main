import React, { useEffect, useMemo, useState } from 'react'
import axios from 'axios'
import { API_BASE_URL } from '../api'
import { SortableHeader, sortRows, TablePagination } from '../components/TableFeatures'

const initialForm = { supplierCode: '', shipmentDate: '', expectedDeliveryDate: '', shipmentStatus: 'Pending', destination: '' }
const statusClass = (status) => `status-pill status-${(status || 'pending').toLowerCase().replace(/\s+/g, '-')}`

function Shipment() {
  const [shipments, setShipments] = useState([])
  const [suppliers, setSuppliers] = useState([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState('')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState(null)
  const [search, setSearch] = useState('')
  const [sortKey, setSortKey] = useState('shipmentDate')
  const [sortDirection, setSortDirection] = useState('desc')
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [statusFilter, setStatusFilter] = useState('All statuses')
  const [formData, setFormData] = useState(initialForm)

  const fetchData = async (initial = false) => {
    setLoadError('')
    if (initial) setLoading(true)
    try {
      const [shipmentsResponse, suppliersResponse] = await Promise.all([
        axios.get(`${API_BASE_URL}/shipments`),
        axios.get(`${API_BASE_URL}/suppliers`)
      ])
      setShipments(shipmentsResponse.data.data || [])
      setSuppliers(suppliersResponse.data.data || [])
    } catch (err) {
      setLoadError('Could not load shipment data. Check your backend and database connection.')
      console.error('Error fetching shipments:', err)
    } finally {
      if (initial) setLoading(false)
    }
  }

  useEffect(() => {
    fetchData(true)
  }, [])

  const filteredShipments = useMemo(() => {
    const query = search.trim().toLowerCase()
    return shipments.filter((shipment) => {
      const matchesSearch = !query || [
        shipment.shipmentNumber, shipment.supplierName, shipment.destination
      ].some((value) => String(value || '').toLowerCase().includes(query))
      return matchesSearch && (statusFilter === 'All statuses' || shipment.shipmentStatus === statusFilter)
    })
  }, [search, shipments, statusFilter])

  const sortedShipments = useMemo(
    () => sortRows(filteredShipments, sortKey, sortDirection),
    [filteredShipments, sortDirection, sortKey]
  )
  const pageCount = Math.max(1, Math.ceil(sortedShipments.length / pageSize))
  const currentPage = Math.min(page, pageCount)
  const visibleShipments = sortedShipments.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  const handleSort = (key) => {
    if (key === sortKey) {
      setSortDirection((direction) => direction === 'asc' ? 'desc' : 'asc')
    } else {
      setSortKey(key)
      setSortDirection('asc')
    }
    setPage(1)
  }

  const resetForm = () => {
    setFormData(initialForm)
    setEditing(null)
    setShowForm(false)
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    setError('')
    setSuccess('')
    try {
      if (editing) {
        await axios.put(`${API_BASE_URL}/shipments/${editing.shipmentNumber}`, formData)
        setSuccess('Shipment updated successfully.')
      } else {
        await axios.post(`${API_BASE_URL}/shipments`, formData)
        setSuccess('Shipment created successfully.')
      }
      resetForm()
      await fetchData()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not save shipment. Please check the details and try again.')
      console.error('Error saving shipment:', err)
    }
  }

  const handleEdit = (shipment) => {
    setEditing(shipment)
    setFormData({
      supplierCode: shipment.supplierCode,
      shipmentDate: String(shipment.shipmentDate).slice(0, 10),
      expectedDeliveryDate: shipment.expectedDeliveryDate ? String(shipment.expectedDeliveryDate).slice(0, 10) : '',
      shipmentStatus: shipment.shipmentStatus || 'Pending',
      destination: shipment.destination || ''
    })
    setShowForm(true)
  }

  const handleDelete = async (shipment) => {
    if (!window.confirm(`Delete shipment #${shipment.shipmentNumber}? Related deliveries may also be removed.`)) return
    setError('')
    setSuccess('')
    try {
      await axios.delete(`${API_BASE_URL}/shipments/${shipment.shipmentNumber}`)
      setSuccess(`Shipment #${shipment.shipmentNumber} deleted.`)
      await fetchData()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not delete shipment.')
      console.error('Error deleting shipment:', err)
    }
  }

  return (
    <div className="page-content shipments-page">
      <header className="page-heading shipments-heading">
        <div className="shipments-heading-copy">
          <p className="eyebrow">Logistics</p>
          <h1 className="page-title">Shipments</h1>
          <p className="page-description">Track, manage, and monitor shipment details.</p>
        </div>
        <div className="shipments-heading-art" aria-hidden="true" />
        <button type="button" className="btn btn-primary shipments-new-button" onClick={() => { resetForm(); setShowForm(true) }}>
          ＋ New shipment
        </button>
      </header>

      {error && <div className="alert alert-error" role="alert">{error}</div>}
      {loadError && (
        <div className="alert alert-error alert-with-action" role="alert">
          <span>{loadError}</span>
          <button type="button" className="btn btn-secondary alert-retry" onClick={() => fetchData(true)}>
            Retry
          </button>
        </div>
      )}
      {success && <div className="alert alert-success" role="status">{success}</div>}

      {showForm && (
        <section className="panel" style={{ marginBottom: 18 }}>
          <div className="panel-heading">
            <div>
              <h2 className="panel-title">{editing ? 'Edit shipment' : 'Create shipment'}</h2>
              <p className="panel-subtitle">Enter the origin partner, target date, and destination.</p>
            </div>
            <button type="button" className="btn btn-secondary" onClick={resetForm}>Close</button>
          </div>
          <form onSubmit={handleSubmit} style={{ padding: 20 }}>
            <div className="form-grid">
              <div>
                <label className="form-label" htmlFor="shipmentSupplier">Supplier *</label>
                <select className="form-control" id="shipmentSupplier" value={formData.supplierCode}
                  onChange={(event) => setFormData({ ...formData, supplierCode: event.target.value })} required>
                  <option value="">Select a supplier</option>
                  {suppliers.map((supplier) => (
                    <option key={supplier.supplierCode} value={supplier.supplierCode}>{supplier.supplierName}</option>
                  ))}
                </select>
                {suppliers.length === 0 && <p className="field-note">Add a supplier before creating a shipment.</p>}
              </div>
              <div>
                <label className="form-label" htmlFor="shipmentDate">Shipment date *</label>
                <input className="form-control" id="shipmentDate" type="date" value={formData.shipmentDate}
                  onChange={(event) => setFormData({ ...formData, shipmentDate: event.target.value })} required />
              </div>
              <div>
                <label className="form-label" htmlFor="expectedDeliveryDate">Expected delivery date</label>
                <input className="form-control" id="expectedDeliveryDate" type="date"
                  min={formData.shipmentDate || undefined}
                  value={formData.expectedDeliveryDate}
                  onChange={(event) => setFormData({ ...formData, expectedDeliveryDate: event.target.value })} />
                <p className="field-note">Optional. Set this to identify late in-transit shipments.</p>
              </div>
              <div>
                <label className="form-label" htmlFor="shipmentStatus">Status</label>
                <select className="form-control" id="shipmentStatus" value={formData.shipmentStatus}
                  onChange={(event) => setFormData({ ...formData, shipmentStatus: event.target.value })}>
                  <option>Pending</option><option>In Transit</option><option>Delivered</option><option>Cancelled</option>
                </select>
              </div>
              <div>
                <label className="form-label" htmlFor="destination">Destination *</label>
                <input className="form-control" id="destination" value={formData.destination}
                  onChange={(event) => setFormData({ ...formData, destination: event.target.value })}
                  placeholder="Warehouse, port, or delivery address" required />
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16 }}>
              <button type="submit" className="btn btn-primary">{editing ? 'Save changes' : 'Create shipment'}</button>
            </div>
          </form>
        </section>
      )}

      <section className="panel shipments-panel">
        <div className="toolbar shipments-toolbar">
          <input className="search-input" type="search" aria-label="Search shipments"
            placeholder="Search shipment, supplier, destination…" value={search}
            onChange={(event) => {
              setSearch(event.target.value)
              setPage(1)
            }} />
          <div className="toolbar-controls">
            <select className="form-control status-select" aria-label="Filter by shipment status"
              value={statusFilter} onChange={(event) => {
                setStatusFilter(event.target.value)
                setPage(1)
              }}>
              <option>All statuses</option><option>Pending</option><option>In Transit</option><option>Delivered</option><option>Cancelled</option>
            </select>
            <span className="result-count">
              {loading ? 'Loading shipments…' : loadError ? 'Shipment data unavailable' : `${filteredShipments.length} of ${shipments.length} shipments`}
            </span>
          </div>
        </div>
        <div className="shipments-table-scroll">
          <table className="data-table shipments-table">
            <thead>
              <tr>
                <SortableHeader columnKey="shipmentNumber" label="#" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="supplierName" label="Supplier" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="shipmentDate" label="Ship date" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="expectedDeliveryDate" label="Expected arrival" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="destination" label="Destination" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="shipmentStatus" label="Status" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {!loading && loadError && (
                <tr><td className="empty-state" colSpan="7">Shipment records are unavailable until loading succeeds.</td></tr>
              )}
              {!loading && !loadError && filteredShipments.length === 0 && (
                <tr><td className="empty-state" colSpan="7">
                  {shipments.length === 0 ? 'No shipments yet. Create your first shipment.' : 'No shipments match the selected filters.'}
                </td></tr>
              )}
              {loading && <tr><td className="empty-state" colSpan="7">Loading shipments…</td></tr>}
              {visibleShipments.map((shipment) => (
                <tr key={shipment.shipmentNumber}>
                  <td><strong style={{ color: '#25364b' }}>#{shipment.shipmentNumber}</strong></td>
                  <td>{shipment.supplierName || '—'}</td>
                  <td>{String(shipment.shipmentDate).slice(0, 10)}</td>
                  <td>{shipment.expectedDeliveryDate ? String(shipment.expectedDeliveryDate).slice(0, 10) : '—'}</td>
                  <td>{shipment.destination}</td>
                  <td><span className={statusClass(shipment.shipmentStatus)}>{shipment.shipmentStatus}</span></td>
                  <td>
                    <div className="row-actions">
                      <button type="button" className="btn btn-secondary" onClick={() => handleEdit(shipment)}>Edit</button>
                      <button type="button" className="btn btn-danger" onClick={() => handleDelete(shipment)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!loading && !loadError && (
          <TablePagination
            total={sortedShipments.length}
            page={currentPage}
            pageSize={pageSize}
            onPageChange={setPage}
            onPageSizeChange={(size) => {
              setPageSize(size)
              setPage(1)
            }}
          />
        )}
      </section>
    </div>
  )
}

export default Shipment
