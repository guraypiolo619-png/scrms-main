// ============================================
// Supply Chain Management System - Backend API
// Main server file with all API endpoints
// ============================================

// Import required modules
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const db = require('./db');
const { createSupplierEvent, createUuid, startOutboxWorker } = require('./integrationGateway');

// Initialize Express application
const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors()); // Enable Cross-Origin Resource Sharing
app.use(express.json()); // Parse JSON request bodies

const isValidDate = (value) => {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
        return false;
    }

    const date = new Date(`${value}T00:00:00.000Z`);
    return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
};

// GET / - API status and available routes
app.get('/', (req, res) => {
    res.json({
        success: true,
        message: 'SCMS backend API is running',
        endpoints: {
            health: 'GET /health',
            login: 'POST /login',
            suppliers: 'GET, POST /suppliers',
            shipments: 'GET, POST /shipments; PUT, DELETE /shipments/:id',
            deliveries: 'GET, POST /deliveries; PUT, DELETE /deliveries/:id',
            reports: 'GET /reports/daily, /reports/weekly, /reports/monthly'
        }
    });
});

// GET /health - Service and database health check
app.get('/health', (req, res) => {
    db.query('SELECT 1', (err) => {
        if (err) {
            return res.status(503).json({
                success: false,
                status: 'unhealthy',
                message: 'Database unreachable'
            });
        }
        res.json({ success: true, status: 'ok' });
    });
});

// ============================================
// AUTHENTICATION ENDPOINTS
// ============================================

// POST /login - Admin login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Validate input
    if (!username || !password) {
        return res.status(400).json({ 
            success: false, 
            message: 'Username and password are required' 
        });
    }

    // Query to find user with matching credentials
    const sql = 'SELECT * FROM users WHERE username = ? AND password = ?';
    
    db.query(sql, [username, password], (err, result) => {
        if (err) {
            return res.status(500).json({ 
                success: false, 
                message: 'Database error', 
                error: err.message 
            });
        }

        if (result.length > 0) {
            // Login successful
            res.json({ 
                success: true, 
                message: 'Login successful',
                user: {
                    id: result[0].id,
                    username: result[0].username
                }
            });
        } else {
            // Login failed
            res.status(401).json({ 
                success: false, 
                message: 'Invalid username or password' 
            });
        }
    });
});

// ============================================
// SUPPLIER ENDPOINTS
// ============================================

// GET /suppliers - Get all suppliers
app.get('/suppliers', (req, res) => {
    const sql = 'SELECT * FROM Supplier ORDER BY supplierCode DESC';
    
    db.query(sql, (err, result) => {
        if (err) {
            return res.status(500).json({ 
                success: false, 
                message: 'Database error', 
                error: err.message 
            });
        }
        res.json({ success: true, data: result });
    });
});

// POST /suppliers - Create a supplier and queue its Gateway event atomically
app.post('/suppliers', (req, res) => {
    const { supplierName, telephone, address, email } = req.body;

    // Validate required fields
    if (!supplierName) {
        return res.status(400).json({ 
            success: false, 
            message: 'Supplier name is required' 
        });
    }

    const eventId = createUuid();
    const correlationId = createUuid();
    db.getConnection((connectionError, connection) => {
        if (connectionError) {
            return res.status(500).json({
                success: false,
                message: 'Database connection failed',
                event_id: eventId,
                correlation_id: correlationId
            });
        }

        connection.beginTransaction((transactionError) => {
            if (transactionError) {
                connection.release();
                return res.status(500).json({
                    success: false,
                    message: 'Could not start supplier transaction',
                    event_id: eventId,
                    correlation_id: correlationId
                });
            }

            const sql = 'INSERT INTO Supplier (supplierName, telephone, address, email) VALUES (?, ?, ?, ?)';
            connection.query(sql, [
                supplierName,
                telephone === undefined ? null : telephone,
                address === undefined ? null : address,
                email === undefined ? null : email
            ], (insertError, result) => {
                if (insertError) {
                    return rollbackSupplierTransaction(connection, res, insertError, eventId, correlationId);
                }

                const supplierCode = String(result.insertId);
                const event = createSupplierEvent({
                    supplierCode,
                    supplierName,
                    telephone: telephone === undefined ? null : telephone,
                    address: address === undefined ? null : address,
                    email: email === undefined ? null : email
                }, correlationId, eventId);
                connection.query(`
                    INSERT INTO integration_outbox
                        (event_id, correlation_id, external_id, event_type, payload, status, next_attempt_at)
                    VALUES (?, ?, ?, ?, ?, 'pending', UTC_TIMESTAMP())
                `, [
                    event.event_id,
                    event.correlation_id,
                    event.external_id,
                    event.event_type,
                    JSON.stringify(event)
                ], (outboxError) => {
                    if (outboxError) {
                        return rollbackSupplierTransaction(connection, res, outboxError, eventId, correlationId);
                    }

                    connection.commit((commitError) => {
                        if (commitError) {
                            return rollbackSupplierTransaction(connection, res, commitError, eventId, correlationId);
                        }
                        connection.release();
                        res.status(201).json({
                            success: true,
                            message: 'Supplier created and integration event queued',
                            supplierCode: result.insertId,
                            event_id: event.event_id,
                            correlation_id: event.correlation_id,
                            integration_status: 'pending'
                        });
                    });
                });
            });
        });
    });
});

function rollbackSupplierTransaction(connection, res, error, eventId, correlationId) {
    connection.rollback(() => {
        connection.release();
        res.status(500).json({
            success: false,
            message: 'Supplier could not be saved with its integration event',
            error: error.message,
            event_id: eventId,
            correlation_id: correlationId
        });
    });
}

// ============================================
// SHIPMENT ENDPOINTS
// ============================================

// GET /shipments - Get all shipments with supplier details
app.get('/shipments', (req, res) => {
    const sql = `
        SELECT 
            s.shipmentNumber,
            s.supplierCode,
            sup.supplierName,
            DATE_FORMAT(s.shipmentDate, '%Y-%m-%d') AS shipmentDate,
            DATE_FORMAT(s.expectedDeliveryDate, '%Y-%m-%d') AS expectedDeliveryDate,
            s.shipmentStatus,
            s.destination
        FROM Shipment s
        INNER JOIN Supplier sup ON s.supplierCode = sup.supplierCode
        ORDER BY s.shipmentNumber DESC
    `;
    
    db.query(sql, (err, result) => {
        if (err) {
            return res.status(500).json({ 
                success: false, 
                message: 'Database error', 
                error: err.message 
            });
        }
        res.json({ success: true, data: result });
    });
});

// POST /shipments - Create new shipment
app.post('/shipments', (req, res) => {
    const { supplierCode, shipmentDate, expectedDeliveryDate, shipmentStatus, destination } = req.body;

    // Validate required fields
    if (!supplierCode || !shipmentDate || !destination) {
        return res.status(400).json({ 
            success: false, 
            message: 'Supplier, shipment date, and destination are required' 
        });
    }

    if (!isValidDate(shipmentDate)) {
        return res.status(400).json({ success: false, message: 'Shipment date must be a valid date' });
    }
    if (expectedDeliveryDate && !isValidDate(expectedDeliveryDate)) {
        return res.status(400).json({ success: false, message: 'Expected delivery date must be a valid date' });
    }
    if (expectedDeliveryDate && expectedDeliveryDate < shipmentDate) {
        return res.status(400).json({ success: false, message: 'Expected delivery date cannot be before the shipment date' });
    }

    const sql = 'INSERT INTO Shipment (supplierCode, shipmentDate, expectedDeliveryDate, shipmentStatus, destination) VALUES (?, ?, ?, ?, ?)';
    
    db.query(sql, [supplierCode, shipmentDate, expectedDeliveryDate || null, shipmentStatus || 'Pending', destination], (err, result) => {
        if (err) {
            return res.status(500).json({ 
                success: false, 
                message: 'Database error', 
                error: err.message 
            });
        }
        res.status(201).json({ 
            success: true, 
            message: 'Shipment created successfully',
            shipmentNumber: result.insertId
        });
    });
});

// PUT /shipments/:id - Update shipment
app.put('/shipments/:id', (req, res) => {
    const { id } = req.params;
    const { supplierCode, shipmentDate, expectedDeliveryDate, shipmentStatus, destination } = req.body;

    if (!supplierCode || !shipmentDate || !destination) {
        return res.status(400).json({
            success: false,
            message: 'Supplier, shipment date, and destination are required'
        });
    }
    if (!isValidDate(shipmentDate)) {
        return res.status(400).json({ success: false, message: 'Shipment date must be a valid date' });
    }
    if (expectedDeliveryDate && !isValidDate(expectedDeliveryDate)) {
        return res.status(400).json({ success: false, message: 'Expected delivery date must be a valid date' });
    }
    if (expectedDeliveryDate && expectedDeliveryDate < shipmentDate) {
        return res.status(400).json({ success: false, message: 'Expected delivery date cannot be before the shipment date' });
    }

    const hasExpectedDeliveryDate = Object.prototype.hasOwnProperty.call(req.body, 'expectedDeliveryDate');
    const sql = hasExpectedDeliveryDate
        ? 'UPDATE Shipment SET supplierCode = ?, shipmentDate = ?, shipmentStatus = ?, destination = ?, expectedDeliveryDate = ? WHERE shipmentNumber = ?'
        : 'UPDATE Shipment SET supplierCode = ?, shipmentDate = ?, shipmentStatus = ?, destination = ? WHERE shipmentNumber = ?';
    const values = [supplierCode, shipmentDate, shipmentStatus, destination];
    if (hasExpectedDeliveryDate) values.push(expectedDeliveryDate || null);
    values.push(id);

    db.query(sql, values, (err, result) => {
        if (err) {
            return res.status(500).json({ 
                success: false, 
                message: 'Database error', 
                error: err.message 
            });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ 
                success: false, 
                message: 'Shipment not found' 
            });
        }
        res.json({ success: true, message: 'Shipment updated successfully' });
    });
});

// DELETE /shipments/:id - Delete shipment
app.delete('/shipments/:id', (req, res) => {
    const { id } = req.params;

    const sql = 'DELETE FROM Shipment WHERE shipmentNumber = ?';
    
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ 
                success: false, 
                message: 'Database error', 
                error: err.message 
            });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ 
                success: false, 
                message: 'Shipment not found' 
            });
        }
        res.json({ success: true, message: 'Shipment deleted successfully' });
    });
});

// ============================================
// DELIVERY ENDPOINTS
// ============================================

// GET /deliveries - Get all deliveries with shipment details
app.get('/deliveries', (req, res) => {
    const sql = `
        SELECT 
            d.deliveryCode,
            d.shipmentNumber,
            s.destination,
            DATE_FORMAT(s.expectedDeliveryDate, '%Y-%m-%d') AS expectedDeliveryDate,
            DATE_FORMAT(d.deliveryDate, '%Y-%m-%d') AS deliveryDate,
            d.quantityDelivered,
            d.deliveryStatus
        FROM Delivery d
        INNER JOIN Shipment s ON d.shipmentNumber = s.shipmentNumber
        ORDER BY d.deliveryCode DESC
    `;
    
    db.query(sql, (err, result) => {
        if (err) {
            return res.status(500).json({ 
                success: false, 
                message: 'Database error', 
                error: err.message 
            });
        }
        res.json({ success: true, data: result });
    });
});

// POST /deliveries - Create new delivery
app.post('/deliveries', (req, res) => {
    const { shipmentNumber, deliveryDate, quantityDelivered, deliveryStatus } = req.body;
    const parsedQuantity = Number(quantityDelivered);

    // Validate required fields
    if (!shipmentNumber || !deliveryDate || quantityDelivered === undefined || quantityDelivered === '') {
        return res.status(400).json({ 
            success: false, 
            message: 'Shipment, delivery date, and quantity are required' 
        });
    }
    if (!isValidDate(deliveryDate)) {
        return res.status(400).json({
            success: false,
            message: 'Delivery date must be a valid date'
        });
    }
    if (!Number.isInteger(parsedQuantity) || parsedQuantity <= 0) {
        return res.status(400).json({
            success: false,
            message: 'Quantity delivered must be a positive whole number'
        });
    }

    const sql = 'INSERT INTO Delivery (shipmentNumber, deliveryDate, quantityDelivered, deliveryStatus) VALUES (?, ?, ?, ?)';
    
    db.query(sql, [shipmentNumber, deliveryDate, parsedQuantity, deliveryStatus || 'Pending'], (err, result) => {
        if (err) {
            return res.status(500).json({ 
                success: false, 
                message: 'Database error', 
                error: err.message 
            });
        }
        res.status(201).json({ 
            success: true, 
            message: 'Delivery created successfully',
            deliveryCode: result.insertId
        });
    });
});

// PUT /deliveries/:id - Update delivery
app.put('/deliveries/:id', (req, res) => {
    const { id } = req.params;
    const { shipmentNumber, deliveryDate, quantityDelivered, deliveryStatus } = req.body;
    const parsedQuantity = Number(quantityDelivered);

    if (!shipmentNumber || !deliveryDate || quantityDelivered === undefined || quantityDelivered === '') {
        return res.status(400).json({
            success: false,
            message: 'Shipment, delivery date, and quantity are required'
        });
    }
    if (!isValidDate(deliveryDate)) {
        return res.status(400).json({
            success: false,
            message: 'Delivery date must be a valid date'
        });
    }
    if (!Number.isInteger(parsedQuantity) || parsedQuantity <= 0) {
        return res.status(400).json({
            success: false,
            message: 'Quantity delivered must be a positive whole number'
        });
    }

    const sql = 'UPDATE Delivery SET shipmentNumber = ?, deliveryDate = ?, quantityDelivered = ?, deliveryStatus = ? WHERE deliveryCode = ?';
    
    db.query(sql, [shipmentNumber, deliveryDate, parsedQuantity, deliveryStatus || 'Pending', id], (err, result) => {
        if (err) {
            return res.status(500).json({ 
                success: false, 
                message: 'Database error', 
                error: err.message 
            });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ 
                success: false, 
                message: 'Delivery not found' 
            });
        }
        res.json({ success: true, message: 'Delivery updated successfully' });
    });
});

// DELETE /deliveries/:id - Delete delivery
app.delete('/deliveries/:id', (req, res) => {
    const { id } = req.params;

    const sql = 'DELETE FROM Delivery WHERE deliveryCode = ?';
    
    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ 
                success: false, 
                message: 'Database error', 
                error: err.message 
            });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ 
                success: false, 
                message: 'Delivery not found' 
            });
        }
        res.json({ success: true, message: 'Delivery deleted successfully' });
    });
});

// ============================================
// REPORTS ENDPOINTS
// ============================================

const deliveryReportQuery = `
    SELECT
        COUNT(*) AS total,
        COALESCE(SUM(CASE
            WHEN d.deliveryStatus = 'Delivered'
                AND s.expectedDeliveryDate IS NOT NULL
                AND d.deliveryDate <= s.expectedDeliveryDate THEN 1
            ELSE 0
        END), 0) AS onTimeDeliveries,
        COALESCE(SUM(CASE
            WHEN d.deliveryStatus = 'Delivered'
                AND s.expectedDeliveryDate IS NOT NULL
                AND d.deliveryDate > s.expectedDeliveryDate THEN 1
            ELSE 0
        END), 0) AS lateDeliveries
    FROM Delivery d
    INNER JOIN Shipment s ON s.shipmentNumber = d.shipmentNumber
    WHERE DATE(d.deliveryDate)
`;

// GET /reports/daily - Daily report
app.get('/reports/daily', (req, res) => {
    const today = new Date().toISOString().split('T')[0];

    const queries = {
        suppliers: 'SELECT COUNT(*) as total FROM Supplier WHERE DATE(created_at) = ?',
        shipments: 'SELECT COUNT(*) as total FROM Shipment WHERE DATE(shipmentDate) = ?',
        deliveries: `${deliveryReportQuery} = ?`
    };

    // Execute all queries
    db.query(queries.suppliers, [today], (err, supplierResult) => {
        if (err) return res.status(500).json({ error: err.message });

        db.query(queries.shipments, [today], (err, shipmentResult) => {
            if (err) return res.status(500).json({ error: err.message });

            db.query(queries.deliveries, [today], (err, deliveryResult) => {
                if (err) return res.status(500).json({ error: err.message });

                res.json({
                    success: true,
                    reportType: 'Daily',
                    date: today,
                    data: {
                        totalSuppliers: Number(supplierResult[0].total || 0),
                        totalShipments: Number(shipmentResult[0].total || 0),
                        totalDeliveries: Number(deliveryResult[0].total || 0),
                        onTimeDeliveries: Number(deliveryResult[0].onTimeDeliveries || 0),
                        lateDeliveries: Number(deliveryResult[0].lateDeliveries || 0)
                    }
                });
            });
        });
    });
});

// GET /reports/weekly - Weekly report
app.get('/reports/weekly', (req, res) => {
    const today = new Date();
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    const weekAgoStr = weekAgo.toISOString().split('T')[0];

    const queries = {
        suppliers: 'SELECT COUNT(*) as total FROM Supplier WHERE DATE(created_at) >= ?',
        shipments: 'SELECT COUNT(*) as total FROM Shipment WHERE DATE(shipmentDate) >= ?',
        deliveries: `${deliveryReportQuery} >= ?`
    };

    db.query(queries.suppliers, [weekAgoStr], (err, supplierResult) => {
        if (err) return res.status(500).json({ error: err.message });

        db.query(queries.shipments, [weekAgoStr], (err, shipmentResult) => {
            if (err) return res.status(500).json({ error: err.message });

            db.query(queries.deliveries, [weekAgoStr], (err, deliveryResult) => {
                if (err) return res.status(500).json({ error: err.message });

                res.json({
                    success: true,
                    reportType: 'Weekly',
                    dateFrom: weekAgoStr,
                    dateTo: today.toISOString().split('T')[0],
                    data: {
                        totalSuppliers: Number(supplierResult[0].total || 0),
                        totalShipments: Number(shipmentResult[0].total || 0),
                        totalDeliveries: Number(deliveryResult[0].total || 0),
                        onTimeDeliveries: Number(deliveryResult[0].onTimeDeliveries || 0),
                        lateDeliveries: Number(deliveryResult[0].lateDeliveries || 0)
                    }
                });
            });
        });
    });
});

// GET /reports/monthly - Monthly report
app.get('/reports/monthly', (req, res) => {
    const today = new Date();
    const year = today.getUTCFullYear();
    const month = today.getUTCMonth();
    const day = today.getUTCDate();
    const daysInPrevMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
    const monthAgo = new Date(Date.UTC(year, month - 1, Math.min(day, daysInPrevMonth)));
    const monthAgoStr = monthAgo.toISOString().split('T')[0];

    const queries = {
        suppliers: 'SELECT COUNT(*) as total FROM Supplier WHERE DATE(created_at) >= ?',
        shipments: 'SELECT COUNT(*) as total FROM Shipment WHERE DATE(shipmentDate) >= ?',
        deliveries: `${deliveryReportQuery} >= ?`
    };

    db.query(queries.suppliers, [monthAgoStr], (err, supplierResult) => {
        if (err) return res.status(500).json({ error: err.message });

        db.query(queries.shipments, [monthAgoStr], (err, shipmentResult) => {
            if (err) return res.status(500).json({ error: err.message });

            db.query(queries.deliveries, [monthAgoStr], (err, deliveryResult) => {
                if (err) return res.status(500).json({ error: err.message });

                res.json({
                    success: true,
                    reportType: 'Monthly',
                    dateFrom: monthAgoStr,
                    dateTo: today.toISOString().split('T')[0],
                    data: {
                        totalSuppliers: Number(supplierResult[0].total || 0),
                        totalShipments: Number(shipmentResult[0].total || 0),
                        totalDeliveries: Number(deliveryResult[0].total || 0),
                        onTimeDeliveries: Number(deliveryResult[0].onTimeDeliveries || 0),
                        lateDeliveries: Number(deliveryResult[0].lateDeliveries || 0)
                    }
                });
            });
        });
    });
});

// ============================================
// START SERVER
// ============================================

app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
    console.log(`📡 API routes are available at http://localhost:${PORT} (for example, /suppliers)`);
    startOutboxWorker(db);
});