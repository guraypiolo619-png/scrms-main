import React, { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Supplier from './pages/Supplier'
import Shipment from './pages/Shipment'
import Delivery from './pages/Delivery'
import Reports from './pages/Reports'
import Navbar from './components/Navbar'

function ProtectedRoute({ children }) {
  const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true'
  return isAuthenticated ? children : <Navigate to="/login" replace />
}

function AppLayout({ children, onLogout }) {
  return (
    <>
      <Navbar onLogout={onLogout} />
      <main className="workspace">{children}</main>
    </>
  )
}

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(
    () => localStorage.getItem('isAuthenticated') === 'true'
  )

  const handleLogin = () => setIsAuthenticated(true)

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated')
    localStorage.removeItem('username')
    setIsAuthenticated(false)
  }

  const protectedPage = (page) => (
    <ProtectedRoute>
      <AppLayout onLogout={handleLogout}>{page}</AppLayout>
    </ProtectedRoute>
  )

  return (
    <Router>
      <Routes>
        <Route
          path="/login"
          element={isAuthenticated ? <Navigate to="/dashboard" replace /> : <Login onLogin={handleLogin} />}
        />
        <Route path="/dashboard" element={protectedPage(<Dashboard />)} />
        <Route path="/supplier" element={protectedPage(<Supplier />)} />
        <Route path="/shipment" element={protectedPage(<Shipment />)} />
        <Route path="/delivery" element={protectedPage(<Delivery />)} />
        <Route path="/reports" element={protectedPage(<Reports />)} />
        <Route path="/" element={<Navigate to={isAuthenticated ? '/dashboard' : '/login'} replace />} />
        <Route path="*" element={<Navigate to={isAuthenticated ? '/dashboard' : '/login'} replace />} />
      </Routes>
    </Router>
  )
}

export default App
