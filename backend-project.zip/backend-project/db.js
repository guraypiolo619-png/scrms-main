// ============================================
// Database Connection Configuration
// This file handles the MySQL database connection
// ============================================

// Import required modules
const mysql = require('mysql2');
require('dotenv').config();

// Create database connection pool
// Using a pool allows multiple connections for better performance
const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',      // Database server address
    port: Number(process.env.DB_PORT) || 3306,      // MySQL default port
    user: process.env.DB_USER || 'root',            // MySQL username
    password: process.env.DB_PASSWORD || '',        // MySQL password
    database: process.env.DB_NAME || 'SCMS',        // Database name
    waitForConnections: true,                       // Wait for available connection
    connectionLimit: 10,                            // Maximum number of connections
    queueLimit: 0                                   // No limit on queued requests
});

// Test database connection
pool.getConnection((err, connection) => {
    if (err) {
        console.error('❌ Database connection failed:', err.message);
        console.log('Please check your MySQL credentials and ensure the SCMS database exists.');
        return;
    }
    console.log('✅ Database connected successfully!');
    connection.release(); // Release the connection back to the pool
});

// Export the pool for use in other files
module.exports = pool;