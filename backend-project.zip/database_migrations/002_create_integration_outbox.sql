-- Apply once to an existing SCMS database.
-- Do not run this after creating the schema from the updated database_script.sql.
CREATE TABLE integration_outbox (
    event_id CHAR(36) NOT NULL PRIMARY KEY,
    correlation_id VARCHAR(255) NOT NULL,
    external_id VARCHAR(255) NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    payload LONGTEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    gateway_status VARCHAR(20) NULL,
    attempt_count INT NOT NULL DEFAULT 0,
    next_attempt_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_error TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX integration_outbox_due_idx (status, next_attempt_at, created_at)
);
