const assert = require('assert');
const http = require('http');
const { createSupplierEvent, sendEvent } = require('./integrationGateway');

async function run() {
    const requests = [];
    const server = http.createServer((request, response) => {
        const chunks = [];
        request.on('data', (chunk) => chunks.push(chunk));
        request.on('end', () => {
            const body = Buffer.concat(chunks).toString('utf8');
            requests.push({ headers: request.headers, body });
            if (requests.length === 1) {
                response.writeHead(202, { 'Content-Type': 'application/json' });
                response.end(JSON.stringify({ event_id: JSON.parse(body).event_id, status: 'received' }));
            } else if (requests.length === 2) {
                response.writeHead(503, { 'Content-Type': 'application/json' });
                response.end(JSON.stringify({ code: 'unavailable', message: 'Try later' }));
            } else {
                response.writeHead(400, { 'Content-Type': 'application/json' });
                response.end(JSON.stringify({ code: 'invalid', message: 'Invalid payload' }));
            }
        });
    });

    const previousUrl = process.env.INTEGRATION_GATEWAY_URL;
    const previousToken = process.env.SUPPLY_CHAIN_INTEGRATION_TOKEN;
    try {
        await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
        process.env.INTEGRATION_GATEWAY_URL = `http://127.0.0.1:${server.address().port}/api/v1/integration`;
        process.env.SUPPLY_CHAIN_INTEGRATION_TOKEN = 'test-token';

        const event = createSupplierEvent({
            supplierCode: 42,
            supplierName: 'Example Supplier',
            telephone: null,
            address: 'Example address',
            email: 'supplier@example.test'
        }, 'correlation-42', '11111111-1111-4111-8111-111111111111');

        assert.strictEqual(event.source_system, 'supply-chain');
        assert.strictEqual(event.event_type, 'supplier-upsert');
        assert.strictEqual(event.external_id, '42');
        assert.strictEqual(event.payload.supplierCode, '42');

        const accepted = await sendEvent(event);
        assert.deepStrictEqual(accepted, { event_id: event.event_id, status: 'received' });
        for (const request of requests) {
            assert.strictEqual(request.headers.authorization, 'Bearer test-token');
            assert.strictEqual(request.headers['idempotency-key'], event.event_id);
            assert.strictEqual(request.headers['x-limbus-system'], 'supply-chain');
            assert.deepStrictEqual(JSON.parse(request.body), event);
        }

        await assert.rejects(sendEvent(event), (error) => error.retryable === true);
        await assert.rejects(sendEvent(event), (error) => error.retryable === false);
        assert.strictEqual(requests[1].headers['idempotency-key'], requests[2].headers['idempotency-key']);
        console.log('Integration Gateway tests passed.');
    } finally {
        if (previousUrl === undefined) delete process.env.INTEGRATION_GATEWAY_URL;
        else process.env.INTEGRATION_GATEWAY_URL = previousUrl;
        if (previousToken === undefined) delete process.env.SUPPLY_CHAIN_INTEGRATION_TOKEN;
        else process.env.SUPPLY_CHAIN_INTEGRATION_TOKEN = previousToken;
        await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
    }
}

run().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
