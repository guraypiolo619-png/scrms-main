const http = require('http');
const https = require('https');
const { randomBytes } = require('crypto');

const RETRY_DELAYS_SECONDS = [1, 5, 15, 60, 300];
const MAX_RESPONSE_BYTES = 1024 * 1024;

function createUuid() {
    const bytes = randomBytes(16);
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = bytes.toString('hex');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

function createSupplierEvent(supplier, correlationId, eventId) {
    const supplierCode = String(supplier.supplierCode);
    return {
        event_id: eventId || createUuid(),
        source_system: 'supply-chain',
        event_type: 'supplier-upsert',
        occurred_at: new Date().toISOString(),
        correlation_id: correlationId,
        external_id: supplierCode,
        payload: {
            supplierCode,
            supplierName: supplier.supplierName,
            telephone: supplier.telephone,
            address: supplier.address,
            email: supplier.email
        }
    };
}

function gatewayConfigurationAvailable() {
    return Boolean(process.env.SUPPLY_CHAIN_INTEGRATION_TOKEN);
}

function sendEvent(event) {
    return new Promise((resolve, reject) => {
        const baseUrl = process.env.INTEGRATION_GATEWAY_URL || 'http://localhost:8088/api/v1/integration';
        const token = process.env.SUPPLY_CHAIN_INTEGRATION_TOKEN;
        if (!token) {
            const error = new Error('SUPPLY_CHAIN_INTEGRATION_TOKEN is not configured');
            error.retryable = false;
            return reject(error);
        }

        let endpoint;
        try {
            endpoint = new URL(`${baseUrl.replace(/\/+$/, '')}/events`);
        } catch (error) {
            error.retryable = false;
            return reject(error);
        }
        if (endpoint.protocol !== 'http:' && endpoint.protocol !== 'https:') {
            const error = new Error('Integration Gateway URL must use HTTP or HTTPS');
            error.retryable = false;
            return reject(error);
        }

        const body = JSON.stringify(event);
        const transport = endpoint.protocol === 'https:' ? https : http;
        const request = transport.request(endpoint, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(body),
                'Idempotency-Key': event.event_id,
                'X-Limbus-System': 'supply-chain'
            },
            timeout: 15000
        }, (response) => {
            let responseBody = '';
            response.setEncoding('utf8');
            response.on('data', (chunk) => {
                responseBody += chunk;
                if (Buffer.byteLength(responseBody) > MAX_RESPONSE_BYTES) {
                    request.destroy(new Error('Integration Gateway response exceeded the size limit'));
                }
            });
            response.on('end', () => {
                let result;
                try {
                    result = JSON.parse(responseBody);
                } catch (error) {
                    error.retryable = response.statusCode >= 500;
                    return reject(error);
                }

                if (response.statusCode < 200 || response.statusCode >= 300) {
                    const error = new Error(result.message || `Integration Gateway returned HTTP ${response.statusCode}`);
                    error.retryable = response.statusCode >= 500;
                    return reject(error);
                }
                if (response.statusCode !== 202 ||
                    result.event_id !== event.event_id ||
                    !['received', 'duplicate', 'succeeded'].includes(result.status)) {
                    const error = new Error('Integration Gateway returned a response that does not match the event contract');
                    error.retryable = true;
                    return reject(error);
                }

                resolve(result);
            });
        });

        request.on('timeout', () => request.destroy(new Error('Integration Gateway request timed out')));
        request.on('error', (error) => {
            if (typeof error.retryable !== 'boolean') error.retryable = true;
            reject(error);
        });
        request.end(body);
    });
}

function query(db, sql, values) {
    return new Promise((resolve, reject) => {
        db.query(sql, values || [], (error, result) => {
            if (error) return reject(error);
            resolve(result);
        });
    });
}

async function processNextEvent(db) {
    if (!gatewayConfigurationAvailable()) return;

    const rows = await query(db, `
        SELECT event_id, payload, attempt_count, status
        FROM integration_outbox
        WHERE (status = 'pending' AND next_attempt_at <= UTC_TIMESTAMP())
           OR (status = 'processing' AND updated_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 2 MINUTE))
        ORDER BY created_at ASC
        LIMIT 1
    `);
    if (rows.length === 0) return;

    const row = rows[0];
    const claim = await query(db, `
        UPDATE integration_outbox
        SET status = 'processing', updated_at = UTC_TIMESTAMP()
        WHERE event_id = ?
          AND ((status = 'pending' AND next_attempt_at <= UTC_TIMESTAMP())
            OR (status = 'processing' AND updated_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 2 MINUTE)))
    `, [row.event_id]);
    if (claim.affectedRows === 0) return;

    const attemptCount = Number(row.attempt_count) + 1;
    try {
        const result = await sendEvent(JSON.parse(row.payload));
        await query(db, `
            UPDATE integration_outbox
            SET status = 'delivered', gateway_status = ?, attempt_count = ?,
                last_error = NULL, updated_at = UTC_TIMESTAMP()
            WHERE event_id = ?
        `, [result.status, attemptCount, row.event_id]);
    } catch (error) {
        const retryable = error.retryable !== false;
        const retryDelay = retryable && attemptCount <= RETRY_DELAYS_SECONDS.length
            ? RETRY_DELAYS_SECONDS[attemptCount - 1]
            : null;
        const status = retryDelay === null ? 'failed' : 'pending';
        const errorMessage = String(error && error.message ? error.message : error).slice(0, 1000);
        await query(db, `
            UPDATE integration_outbox
            SET status = ?, attempt_count = ?,
                next_attempt_at = IF(? IS NULL, next_attempt_at, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND)),
                last_error = ?, updated_at = UTC_TIMESTAMP()
            WHERE event_id = ?
        `, [status, attemptCount, retryDelay, retryDelay, errorMessage, row.event_id]);
        console.error(`Integration event ${row.event_id} ${status}: ${errorMessage}`);
    }
}

function startOutboxWorker(db) {
    let running = false;
    if (!gatewayConfigurationAvailable()) {
        console.warn('SUPPLY_CHAIN_INTEGRATION_TOKEN is not configured; Gateway events will remain pending.');
    }
    const process = async () => {
        if (running) return;
        running = true;
        try {
            await processNextEvent(db);
        } catch (error) {
            console.error('Integration outbox processing failed:', error.message);
        } finally {
            running = false;
        }
    };
    process();
    setInterval(process, 1000);
}

module.exports = {
    createSupplierEvent,
    createUuid,
    sendEvent,
    startOutboxWorker
};
