import React, { useEffect, useMemo, useState } from 'react'
import axios from 'axios'
import { API_BASE_URL } from '../api'
import { SortableHeader, sortRows, TablePagination } from '../components/TableFeatures'

const emptyForm = { supplierName: '', telephone: '', address: '', email: '' }

function Supplier() {
  const [suppliers, setSuppliers] = useState([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState('')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [search, setSearch] = useState('')
  const [sortKey, setSortKey] = useState('supplierName')
  const [sortDirection, setSortDirection] = useState('asc')
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [formData, setFormData] = useState(emptyForm)

  const fetchSuppliers = async () => {
    setLoading(true)
    setLoadError('')
    try {
      const response = await axios.get(`${API_BASE_URL}/suppliers`)
      setSuppliers(response.data.data || [])
    } catch (err) {
      setLoadError('Could not load suppliers. Check your backend and database connection.')
      console.error('Error fetching suppliers:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchSuppliers()
  }, [])

  const filteredSuppliers = useMemo(() => {
    const query = search.trim().toLowerCase()
    if (!query) return suppliers
    return suppliers.filter((supplier) =>
      [supplier.supplierName, supplier.email, supplier.telephone, supplier.address]
        .some((value) => String(value || '').toLowerCase().includes(query))
    )
  }, [search, suppliers])

  const sortedSuppliers = useMemo(
    () => sortRows(filteredSuppliers, sortKey, sortDirection),
    [filteredSuppliers, sortDirection, sortKey]
  )
  const pageCount = Math.max(1, Math.ceil(sortedSuppliers.length / pageSize))
  const currentPage = Math.min(page, pageCount)
  const visibleSuppliers = sortedSuppliers.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  const handleSort = (key) => {
    if (key === sortKey) {
      setSortDirection((direction) => direction === 'asc' ? 'desc' : 'asc')
    } else {
      setSortKey(key)
      setSortDirection('asc')
    }
    setPage(1)
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    setError('')
    setSuccess('')
    try {
      const response = await axios.post(`${API_BASE_URL}/suppliers`, formData)
      const { event_id: eventId, correlation_id: correlationId } = response.data
      if (!eventId || !correlationId) {
        throw new Error('Supplier was saved without integration event identifiers.')
      }
      setFormData(emptyForm)
      setShowForm(false)
      setSuccess(`Supplier added. Gateway event ${eventId} (correlation ${correlationId}) is queued.`)
      await fetchSuppliers()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not save supplier. Please try again.')
      console.error('Error creating supplier:', err)
    }
  }

  return (
    <div className="page-content suppliers-page">
      <header className="page-heading suppliers-heading">
        <div className="suppliers-heading-copy">
          <p className="eyebrow">Partner network</p>
          <h1 className="page-title">Suppliers</h1>
          <p className="page-description">Manage your supply partners and contact details.</p>
        </div>
        <div className="suppliers-heading-art" aria-hidden="true" />
        <button type="button" className="btn btn-primary suppliers-add-button" onClick={() => setShowForm(!showForm)}>
          {showForm ? 'Cancel' : '＋ Add Supplier'}
        </button>
      </header>

      {error && <div className="alert alert-error" role="alert">{error}</div>}
      {loadError && (
        <div className="alert alert-error alert-with-action" role="alert">
          <span>{loadError}</span>
          <button type="button" className="btn btn-secondary alert-retry" onClick={fetchSuppliers}>
            Retry
          </button>
        </div>
      )}
      {success && <div className="alert alert-success" role="status">{success}</div>}

      {showForm && (
        <section className="panel suppliers-form-panel" style={{ marginBottom: 18 }}>
          <div className="panel-heading">
            <div>
              <h2 className="panel-title">Add a supplier</h2>
              <p className="panel-subtitle">Enter the partner’s primary contact details.</p>
            </div>
          </div>
          <form onSubmit={handleSubmit} style={{ padding: 20 }}>
            <div className="form-grid">
              <div>
                <label className="form-label" htmlFor="supplierName">Supplier name *</label>
                <input className="form-control" id="supplierName" name="supplierName" value={formData.supplierName}
                  onChange={(event) => setFormData({ ...formData, supplierName: event.target.value })}
                  placeholder="Company or partner name" required />
              </div>
              <div>
                <label className="form-label" htmlFor="supplierEmail">Email</label>
                <input className="form-control" id="supplierEmail" name="email" type="email" value={formData.email}
                  onChange={(event) => setFormData({ ...formData, email: event.target.value })}
                  placeholder="name@company.com" />
              </div>
              <div>
                <label className="form-label" htmlFor="supplierPhone">Telephone</label>
                <input className="form-control" id="supplierPhone" name="telephone" value={formData.telephone}
                  onChange={(event) => setFormData({ ...formData, telephone: event.target.value })}
                  placeholder="Phone number" />
              </div>
              <div>
                <label className="form-label" htmlFor="supplierAddress">Address</label>
                <input className="form-control" id="supplierAddress" name="address" value={formData.address}
                  onChange={(event) => setFormData({ ...formData, address: event.target.value })}
                  placeholder="Business address" />
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16 }}>
              <button type="submit" className="btn btn-primary">Save supplier</button>
            </div>
          </form>
        </section>
      )}

      <section className="panel suppliers-panel">
        <div className="toolbar suppliers-toolbar">
          <input
            className="search-input"
            type="search"
            aria-label="Search suppliers"
            placeholder="Search suppliers, email, phone…"
            value={search}
            onChange={(event) => {
              setSearch(event.target.value)
              setPage(1)
            }}
          />
          <span className="suppliers-count">
            {loading ? 'Loading suppliers…' : loadError ? 'Supplier data unavailable' : `${filteredSuppliers.length} of ${suppliers.length} suppliers`}
          </span>
        </div>
        <div className="suppliers-table-scroll">
          <table className="data-table suppliers-table">
            <thead>
              <tr>
                <SortableHeader columnKey="supplierName" label="Supplier" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="email" label="Email" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="telephone" label="Telephone" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="address" label="Address" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
              </tr>
            </thead>
            <tbody>
              {!loading && loadError && (
                <tr><td className="empty-state" colSpan="4">Supplier records are unavailable until loading succeeds.</td></tr>
              )}
              {!loading && !loadError && filteredSuppliers.length === 0 && (
                <tr>
                  <td className="empty-state" colSpan="4">
                    {suppliers.length === 0 ? 'No suppliers yet. Add your first supply partner.' : 'No suppliers match your search.'}
                  </td>
                </tr>
              )}
              {loading && <tr><td className="empty-state" colSpan="4">Loading suppliers…</td></tr>}
              {visibleSuppliers.map((supplier) => (
                <tr key={supplier.supplierCode}>
                  <td>
                    <div className="supplier-identity">
                      <strong>{supplier.supplierName}</strong>
                      <span>SUP-{String(supplier.supplierCode).padStart(4, '0')}</span>
                    </div>
                  </td>
                  <td>{supplier.email || '—'}</td>
                  <td>{supplier.telephone || '—'}</td>
                  <td>{supplier.address || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!loading && !loadError && (
          <TablePagination
            total={sortedSuppliers.length}
            page={currentPage}
            pageSize={pageSize}
            onPageChange={setPage}
            onPageSizeChange={(size) => {
              setPageSize(size)
              setPage(1)
            }}
          />
        )}
      </section>
    </div>
  )
}

export default Supplier
