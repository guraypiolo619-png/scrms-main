import assert from 'node:assert/strict'
import test from 'node:test'
import { getShipmentDateAlerts } from './shipmentAlerts.js'

test('flags past pending ship dates and late in-transit expected dates only', () => {
  const shipments = [
    { shipmentNumber: 1, shipmentStatus: 'Pending', shipmentDate: '2026-11-19' },
    { shipmentNumber: 2, shipmentStatus: 'In Transit', shipmentDate: '2026-11-10', expectedDeliveryDate: '2026-11-18' },
    { shipmentNumber: 3, shipmentStatus: 'Pending', shipmentDate: '2026-11-20' },
    { shipmentNumber: 4, shipmentStatus: 'In Transit', shipmentDate: '2026-11-10', expectedDeliveryDate: null },
    { shipmentNumber: 5, shipmentStatus: 'Delivered', shipmentDate: '2026-11-01', expectedDeliveryDate: '2026-11-01' },
    { shipmentNumber: 6, shipmentStatus: 'Cancelled', shipmentDate: '2026-11-01' },
    { shipmentNumber: 7, shipmentStatus: 'In Transit', shipmentDate: '2026-11-10', expectedDeliveryDate: '2026-11-21' }
  ]

  const alerts = getShipmentDateAlerts(shipments, '2026-11-20')

  assert.deepEqual(alerts.shipmentsNeedingAttention.map(({ shipmentNumber }) => shipmentNumber), [2, 1])
  assert.equal(alerts.overdueDepartures.length, 1)
  assert.equal(alerts.lateInTransit.length, 1)
  assert.equal(
    alerts.attentionSummary,
    '1 pending shipment past its scheduled ship date; 1 in-transit shipment past its expected arrival date'
  )
})

test('ignores malformed and same-day dates', () => {
  const alerts = getShipmentDateAlerts([
    { shipmentNumber: 1, shipmentStatus: 'Pending', shipmentDate: 'not-a-date' },
    { shipmentNumber: 2, shipmentStatus: 'In Transit', expectedDeliveryDate: '2026-11-20' }
  ], '2026-11-20')

  assert.equal(alerts.shipmentsNeedingAttention.length, 0)
  assert.equal(alerts.attentionSummary, '')
})
