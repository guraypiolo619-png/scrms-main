function isPastDate(value, todayKey) {
  const date = String(value || '').slice(0, 10)
  return /^\d{4}-\d{2}-\d{2}$/.test(date) && date < todayKey
}

export function getShipmentDateAlerts(shipments, todayKey) {
  const overdueDepartures = shipments
    .filter(({ shipmentStatus, shipmentDate }) => (
      shipmentStatus === 'Pending' && isPastDate(shipmentDate, todayKey)
    ))
    .map((shipment) => ({
      ...shipment,
      attentionType: 'Past ship date',
      attentionDate: String(shipment.shipmentDate).slice(0, 10)
    }))

  const lateInTransit = shipments
    .filter(({ shipmentStatus, expectedDeliveryDate }) => (
      shipmentStatus === 'In Transit' && isPastDate(expectedDeliveryDate, todayKey)
    ))
    .map((shipment) => ({
      ...shipment,
      attentionType: 'Late in transit',
      attentionDate: String(shipment.expectedDeliveryDate).slice(0, 10)
    }))

  const shipmentsNeedingAttention = [...overdueDepartures, ...lateInTransit]
    .sort((first, second) => first.attentionDate.localeCompare(second.attentionDate))

  const attentionSummary = [
    overdueDepartures.length > 0
      && `${overdueDepartures.length} pending shipment${overdueDepartures.length === 1 ? '' : 's'} past ${overdueDepartures.length === 1 ? 'its' : 'their'} scheduled ship date${overdueDepartures.length === 1 ? '' : 's'}`,
    lateInTransit.length > 0
      && `${lateInTransit.length} in-transit shipment${lateInTransit.length === 1 ? '' : 's'} past ${lateInTransit.length === 1 ? 'its' : 'their'} expected arrival date${lateInTransit.length === 1 ? '' : 's'}`
  ].filter(Boolean).join('; ')

  return { overdueDepartures, lateInTransit, shipmentsNeedingAttention, attentionSummary }
}
