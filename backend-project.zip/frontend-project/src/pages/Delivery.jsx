import React, { useEffect, useMemo, useState } from 'react'
import axios from 'axios'
import { API_BASE_URL } from '../api'
import { SortableHeader, sortRows, TablePagination } from '../components/TableFeatures'
import { getDeliveryPerformance } from '../utils/deliveryPerformance'

const initialForm = { shipmentNumber: '', deliveryDate: '', quantityDelivered: '', deliveryStatus: 'Pending' }
const statusClass = (status) => `status-pill status-${(status || 'pending').toLowerCase().replace(/\s+/g, '-')}`

function Delivery() {
  const [deliveries, setDeliveries] = useState([])
  const [shipments, setShipments] = useState([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState('')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState(null)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('All statuses')
  const [sortKey, setSortKey] = useState('deliveryDate')
  const [sortDirection, setSortDirection] = useState('desc')
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [formData, setFormData] = useState(initialForm)

  const fetchData = async (initial = false) => {
    setLoadError('')
    if (initial) setLoading(true)
    try {
      const [deliveriesResponse, shipmentsResponse] = await Promise.all([
        axios.get(`${API_BASE_URL}/deliveries`),
        axios.get(`${API_BASE_URL}/shipments`)
      ])
      setDeliveries(deliveriesResponse.data.data || [])
      setShipments(shipmentsResponse.data.data || [])
    } catch (err) {
      setLoadError('Could not load delivery data. Check your backend and database connection.')
      console.error('Error fetching deliveries:', err)
    } finally {
      if (initial) setLoading(false)
    }
  }

  useEffect(() => {
    fetchData(true)
  }, [])

  const filteredDeliveries = useMemo(() => {
    const query = search.trim().toLowerCase()
    return deliveries.filter((delivery) => {
      const matchesSearch = !query || [
        delivery.deliveryCode, delivery.shipmentNumber, delivery.destination
      ].some((value) => String(value || '').toLowerCase().includes(query))
      return matchesSearch && (statusFilter === 'All statuses' || delivery.deliveryStatus === statusFilter)
    })
  }, [deliveries, search, statusFilter])

  const sortedDeliveries = useMemo(
    () => sortRows(filteredDeliveries, sortKey, sortDirection, 'deliveryCode'),
    [filteredDeliveries, sortDirection, sortKey]
  )
  const pageCount = Math.max(1, Math.ceil(sortedDeliveries.length / pageSize))
  const currentPage = Math.min(page, pageCount)
  const visibleDeliveries = sortedDeliveries.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  const handleSort = (key) => {
    if (key === sortKey) {
      setSortDirection((direction) => direction === 'asc' ? 'desc' : 'asc')
    } else {
      setSortKey(key)
      setSortDirection('asc')
    }
    setPage(1)
  }

  const resetForm = () => {
    setFormData(initialForm)
    setEditing(null)
    setShowForm(false)
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    setError('')
    setSuccess('')
    try {
      if (editing) {
        await axios.put(`${API_BASE_URL}/deliveries/${editing.deliveryCode}`, formData)
        setSuccess('Delivery updated successfully.')
      } else {
        await axios.post(`${API_BASE_URL}/deliveries`, formData)
        setSuccess('Delivery recorded successfully.')
      }
      resetForm()
      await fetchData()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not save delivery. Please check the details and try again.')
      console.error('Error saving delivery:', err)
    }
  }

  const handleEdit = (delivery) => {
    setEditing(delivery)
    setFormData({
      shipmentNumber: delivery.shipmentNumber,
      deliveryDate: String(delivery.deliveryDate).slice(0, 10),
      quantityDelivered: delivery.quantityDelivered,
      deliveryStatus: delivery.deliveryStatus || 'Pending'
    })
    setShowForm(true)
  }

  const handleDelete = async (delivery) => {
    if (!window.confirm(`Delete delivery record #${delivery.deliveryCode}?`)) return
    setError('')
    setSuccess('')
    try {
      await axios.delete(`${API_BASE_URL}/deliveries/${delivery.deliveryCode}`)
      setSuccess(`Delivery record #${delivery.deliveryCode} deleted.`)
      await fetchData()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not delete delivery.')
      console.error('Error deleting delivery:', err)
    }
  }

  return (
    <div className="page-content deliveries-page">
      <header className="page-heading deliveries-heading">
        <div className="deliveries-heading-copy">
          <p className="eyebrow">Performance</p>
          <h1 className="page-title">Deliveries</h1>
          <p className="page-description">Track and manage delivery shipments.</p>
        </div>
        <div className="deliveries-heading-art" aria-hidden="true" />
        <button type="button" className="btn btn-primary deliveries-record-button" onClick={() => { resetForm(); setShowForm(true) }}>
          ＋ Record Delivery
        </button>
      </header>

      {error && <div className="alert alert-error" role="alert">{error}</div>}
      {loadError && (
        <div className="alert alert-error alert-with-action" role="alert">
          <span>{loadError}</span>
          <button type="button" className="btn btn-secondary alert-retry" onClick={() => fetchData(true)}>
            Retry
          </button>
        </div>
      )}
      {success && <div className="alert alert-success" role="status">{success}</div>}

      {showForm && (
        <section className="panel" style={{ marginBottom: 18 }}>
          <div className="panel-heading">
            <div>
              <h2 className="panel-title">{editing ? 'Edit delivery' : 'Record a delivery'}</h2>
              <p className="panel-subtitle">Link the delivery to a shipment and record the received quantity.</p>
            </div>
            <button type="button" className="btn btn-secondary" onClick={resetForm}>Close</button>
          </div>
          <form onSubmit={handleSubmit} style={{ padding: 20 }}>
            <div className="form-grid">
              <div>
                <label className="form-label" htmlFor="deliveryShipment">Shipment *</label>
                <select className="form-control" id="deliveryShipment" value={formData.shipmentNumber}
                  onChange={(event) => setFormData({ ...formData, shipmentNumber: event.target.value })} required>
                  <option value="">Select a shipment</option>
                  {shipments.map((shipment) => (
                    <option key={shipment.shipmentNumber} value={shipment.shipmentNumber}>
                      #{shipment.shipmentNumber} · {shipment.destination}
                    </option>
                  ))}
                </select>
                {shipments.length === 0 && <p className="field-note">Create a shipment before recording a delivery.</p>}
              </div>
              <div>
                <label className="form-label" htmlFor="deliveryDate">Delivery date *</label>
                <input className="form-control" id="deliveryDate" type="date" value={formData.deliveryDate}
                  onChange={(event) => setFormData({ ...formData, deliveryDate: event.target.value })} required />
              </div>
              <div>
                <label className="form-label" htmlFor="quantityDelivered">Quantity received *</label>
                <input className="form-control" id="quantityDelivered" type="number" min="1"
                  value={formData.quantityDelivered}
                  onChange={(event) => setFormData({ ...formData, quantityDelivered: event.target.value })}
                  placeholder="Enter quantity" required />
              </div>
              <div>
                <label className="form-label" htmlFor="deliveryStatus">Status</label>
                <select className="form-control" id="deliveryStatus" value={formData.deliveryStatus}
                  onChange={(event) => setFormData({ ...formData, deliveryStatus: event.target.value })}>
                  <option>Pending</option><option>In Transit</option><option>Delivered</option><option>Failed</option>
                </select>
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16 }}>
              <button type="submit" className="btn btn-primary">{editing ? 'Save changes' : 'Save delivery'}</button>
            </div>
          </form>
        </section>
      )}

      <section className="panel deliveries-panel">
        <div className="toolbar deliveries-toolbar">
          <input className="search-input" type="search" aria-label="Search deliveries"
            placeholder="Search delivery, shipment, destination…" value={search}
            onChange={(event) => {
              setSearch(event.target.value)
              setPage(1)
            }} />
          <div className="toolbar-controls">
            <select className="form-control status-select" aria-label="Filter by delivery status"
              value={statusFilter} onChange={(event) => {
                setStatusFilter(event.target.value)
                setPage(1)
              }}>
              <option>All statuses</option><option>Pending</option><option>In Transit</option><option>Delivered</option><option>Failed</option>
            </select>
            <span className="result-count">
              {loading ? 'Loading deliveries…' : loadError ? 'Delivery data unavailable' : `${filteredDeliveries.length} of ${deliveries.length} deliveries`}
            </span>
          </div>
        </div>
        <div className="deliveries-table-scroll">
          <table className="data-table deliveries-table">
            <thead>
              <tr>
                <SortableHeader columnKey="deliveryCode" label="#" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="shipmentNumber" label="Shipment" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="destination" label="Destination" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="expectedDeliveryDate" label="Expected" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="deliveryDate" label="Received" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="quantityDelivered" label="Quantity" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <SortableHeader columnKey="deliveryStatus" label="Status" sortKey={sortKey} sortDirection={sortDirection} onSort={handleSort} />
                <th scope="col">Timeliness</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {!loading && loadError && (
                <tr><td className="empty-state" colSpan="9">Delivery records are unavailable until loading succeeds.</td></tr>
              )}
              {!loading && !loadError && filteredDeliveries.length === 0 && (
                <tr><td className="empty-state" colSpan="9">
                  {deliveries.length === 0 ? 'No deliveries recorded yet.' : 'No deliveries match the selected filters.'}
                </td></tr>
              )}
              {loading && <tr><td className="empty-state" colSpan="9">Loading deliveries…</td></tr>}
              {visibleDeliveries.map((delivery) => {
                const performance = getDeliveryPerformance(delivery)
                return (
                  <tr key={delivery.deliveryCode}>
                    <td><strong style={{ color: '#25364b' }}>#{delivery.deliveryCode}</strong></td>
                    <td>#{delivery.shipmentNumber}</td>
                    <td>{delivery.destination || '—'}</td>
                    <td>{delivery.expectedDeliveryDate || '—'}</td>
                    <td>{String(delivery.deliveryDate).slice(0, 10)}</td>
                    <td>{delivery.quantityDelivered}</td>
                    <td><span className={statusClass(delivery.deliveryStatus)}>{delivery.deliveryStatus}</span></td>
                    <td>
                      <span className={`delivery-performance-badge is-${performance.tone}`}>
                        {performance.label}
                      </span>
                    </td>
                    <td>
                      <div className="row-actions">
                        <button type="button" className="btn btn-secondary" onClick={() => handleEdit(delivery)}>Edit</button>
                        <button type="button" className="btn btn-danger" onClick={() => handleDelete(delivery)}>Delete</button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
        {!loading && !loadError && (
          <TablePagination
            total={sortedDeliveries.length}
            page={currentPage}
            pageSize={pageSize}
            onPageChange={setPage}
            onPageSizeChange={(size) => {
              setPageSize(size)
              setPage(1)
            }}
          />
        )}
      </section>
    </div>
  )
}

export default Delivery
