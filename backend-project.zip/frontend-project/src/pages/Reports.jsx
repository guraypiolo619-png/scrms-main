import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { API_BASE_URL } from '../api'

const reportTypes = [
  { id: 'daily', label: 'Daily' },
  { id: 'weekly', label: 'Weekly' },
  { id: 'monthly', label: 'Monthly' }
]

function Reports() {
  const [activeReport, setActiveReport] = useState('daily')
  const [reportData, setReportData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [retryCount, setRetryCount] = useState(0)

  useEffect(() => {
    let active = true
    const fetchReport = async () => {
      setLoading(true)
      setError('')
      try {
        const response = await axios.get(`${API_BASE_URL}/reports/${activeReport}`)
        if (active) setReportData(response.data)
      } catch (err) {
        if (active) setError('Could not load this report. Check that the backend and database are available.')
        console.error('Error fetching report:', err)
      } finally {
        if (active) setLoading(false)
      }
    }

    fetchReport()
    return () => { active = false }
  }, [activeReport, retryCount])

  const metrics = reportData?.data
  const onTimeDeliveries = Number(metrics?.onTimeDeliveries ?? 0)
  const lateDeliveries = Number(metrics?.lateDeliveries ?? 0)
  const measuredDeliveries = onTimeDeliveries + lateDeliveries
  const onTimeRate = measuredDeliveries > 0
    ? Math.round((onTimeDeliveries / measuredDeliveries) * 100)
    : null
  const period = reportData?.dateFrom && reportData?.dateTo
    ? `${reportData.dateFrom} — ${reportData.dateTo}`
    : reportData?.date

  const handleExport = () => {
    if (!metrics) return

    const rows = [
      ['SCMS Report', activeReport],
      ['Reporting period', period || ''],
      [],
      ['Metric', 'Total'],
      ['Suppliers added', metrics.totalSuppliers ?? 0],
      ['Shipments scheduled', metrics.totalShipments ?? 0],
      ['Deliveries recorded', metrics.totalDeliveries ?? 0],
      ['On-time deliveries', onTimeDeliveries],
      ['Late deliveries', lateDeliveries],
      ['On-time delivery rate', onTimeRate === null ? 'N/A' : `${onTimeRate}%`]
    ]
    const csv = rows.map((row) => row.map((value) => (
      `"${String(value).replace(/"/g, '""')}"`
    )).join(',')).join('\r\n')
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }))
    const link = document.createElement('a')
    link.href = url
    link.download = `scms-${activeReport}-report.csv`
    document.body.appendChild(link)
    link.click()
    link.remove()
    window.setTimeout(() => URL.revokeObjectURL(url), 1000)
  }

  return (
    <div className="page-content reports-page">
      <header className="page-heading reports-heading">
        <div className="reports-heading-copy">
          <p className="eyebrow">Performance</p>
          <h1 className="page-title">Reports</h1>
          <p className="page-description">Reports on shipment and delivery activity for a selected period.</p>
        </div>
        <div className="reports-heading-actions">
          <label className="reports-period-select">
            <span className="sr-only">Report period</span>
            <select value={activeReport} onChange={(event) => setActiveReport(event.target.value)}>
              <option value="daily">Today</option>
              <option value="weekly">This Week</option>
              <option value="monthly">This Month</option>
            </select>
          </label>
          <button type="button" className="btn btn-primary reports-export" onClick={handleExport} disabled={loading || !metrics}>
            <svg viewBox="0 0 20 20" aria-hidden="true">
              <path d="M10 2.5v9m0 0 3.5-3.5M10 11.5 6.5 8M3.5 13.5v3h13v-3" />
            </svg>
            Export Report
          </button>
        </div>
      </header>

      <section className="panel report-panel">
        <div className="report-toolbar">
          <div className="report-tabs" role="tablist" aria-label="Report frequency">
            {reportTypes.map((type) => (
              <button
                key={type.id}
                type="button"
                role="tab"
                aria-selected={activeReport === type.id}
                className={`report-tab${activeReport === type.id ? ' active' : ''}`}
                onClick={() => setActiveReport(type.id)}
              >
                {type.label}
              </button>
            ))}
          </div>
          {period && <span className="report-period">Reporting period: <strong>{period}</strong></span>}
        </div>

        {error && (
          <div className="alert alert-error alert-with-action" role="alert" style={{ margin: 18 }}>
            <span>{error}</span>
            <button type="button" className="btn btn-secondary alert-retry" onClick={() => setRetryCount((count) => count + 1)}>
              Retry
            </button>
          </div>
        )}

        {loading ? (
          <div className="empty-state" role="status" aria-live="polite">Loading report…</div>
        ) : metrics ? (
          <div className="reports-body">
            <div className="reports-overview">
              <div className="report-metrics">
              <article className="report-metric">
                <span className="report-metric-icon">◇</span>
                <p className="report-metric-label">Suppliers added</p>
                <p className="report-metric-value">{metrics.totalSuppliers ?? 0}</p>
                <p className="report-metric-note">New partner records during this period</p>
              </article>
              <article className="report-metric">
                <span className="report-metric-icon">▣</span>
                <p className="report-metric-label">Shipments scheduled</p>
                <p className="report-metric-value">{metrics.totalShipments ?? 0}</p>
                <p className="report-metric-note">Shipments dated during this period</p>
              </article>
              <article className="report-metric">
                <span className="report-metric-icon">↗</span>
                <p className="report-metric-label">Deliveries recorded</p>
                <p className="report-metric-value">{metrics.totalDeliveries ?? 0}</p>
                <p className="report-metric-note">Delivery records dated during this period</p>
              </article>
              </div>
              <div className="reports-chart" aria-hidden="true">
                <svg viewBox="0 0 240 150">
                  <defs>
                    <linearGradient id="reportBarGradient" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0" stopColor="#15c4bc" stopOpacity=".78" />
                      <stop offset="1" stopColor="#15c4bc" stopOpacity=".12" />
                    </linearGradient>
                  </defs>
                  <path d="M15 130H225" stroke="#d8edf0" strokeWidth="1" />
                  <rect x="34" y="91" width="23" height="39" rx="4" fill="url(#reportBarGradient)" />
                  <rect x="72" y="72" width="23" height="58" rx="4" fill="url(#reportBarGradient)" />
                  <rect x="110" y="83" width="23" height="47" rx="4" fill="url(#reportBarGradient)" />
                  <rect x="148" y="48" width="23" height="82" rx="4" fill="url(#reportBarGradient)" />
                  <rect x="186" y="31" width="23" height="99" rx="4" fill="url(#reportBarGradient)" />
                  <path d="m23 91 40-12 34 8 38-28 37-13 30-28" fill="none" stroke="#10b8b2" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" />
                  <path d="m191 18 12-2-2 12" fill="none" stroke="#10b8b2" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" />
                </svg>
              </div>
            </div>

            <section className="report-delivery-performance" aria-label="Delivery timeliness">
              <div className="report-performance-stat is-on-time">
                <span>On-time deliveries</span>
                <strong>{onTimeDeliveries}</strong>
              </div>
              <div className="report-performance-stat is-late">
                <span>Late deliveries</span>
                <strong>{lateDeliveries}</strong>
              </div>
              <div className="report-performance-stat is-rate">
                <span>On-time rate</span>
                <strong>{onTimeRate === null ? '—' : `${onTimeRate}%`}</strong>
              </div>
              <p>Only completed deliveries with an expected date are included.</p>
            </section>

            <div className="report-summary">
              <div>
                <h2 className="panel-title">Activity summary</h2>
                <p className="panel-subtitle">A concise view of recorded operations for this period.</p>
              </div>
              <strong className="report-total">
                {(metrics.totalSuppliers || 0) + (metrics.totalShipments || 0) + (metrics.totalDeliveries || 0)} records
              </strong>
            </div>
            <div className="report-list">
              <div><span>Supplier records</span><strong>{metrics.totalSuppliers ?? 0}</strong></div>
              <div><span>Shipment records</span><strong>{metrics.totalShipments ?? 0}</strong></div>
              <div><span>Delivery records</span><strong>{metrics.totalDeliveries ?? 0}</strong></div>
            </div>
          </div>
        ) : !error ? (
          <div className="empty-state">No report data is available.</div>
        ) : null}
      </section>
    </div>
  )
}

export default Reports
